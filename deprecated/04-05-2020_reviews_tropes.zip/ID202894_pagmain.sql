-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Hôte : mysql168.webhosting.be:3306
-- Généré le : lun. 04 mai 2020 à 20:07
-- Version du serveur :  5.7.29-32-log
-- Version de PHP : 7.1.25-1+0~20181207224605.11+jessie~1.gbpf65b84

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ID202894_pagmain`
--

-- --------------------------------------------------------

--
-- Structure de la table `commentables`
--

CREATE TABLE `commentables` (
  `id_commentable` int(10) UNSIGNED NOT NULL,
  `pseudo` varchar(20) COLLATE utf8_unicode_520_ci NOT NULL COMMENT 'Author of the content.',
  `title` varchar(60) COLLATE utf8_unicode_520_ci NOT NULL,
  `date_publication` datetime NOT NULL,
  `date_last_edition` datetime NOT NULL,
  `votes_relevant` smallint(6) UNSIGNED NOT NULL,
  `votes_irrelevant` smallint(6) UNSIGNED NOT NULL,
  `id_topic` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;

--
-- Déchargement des données de la table `commentables`
--

INSERT INTO `commentables` (`id_commentable`, `pseudo`, `title`, `date_publication`, `date_last_edition`, `votes_relevant`, `votes_irrelevant`, `id_topic`) VALUES
(1, 'JefGrailet', 'Le monde ouvert selon Nintendo', '2017-09-04 19:02:27', '1970-01-01 00:00:00', 1, 0, NULL),
(4, 'Doppelganger', 'La même chose que le boss!', '2018-01-14 17:18:34', '1970-01-01 00:00:00', 1, 0, NULL),
(5, 'JefGrailet', 'Un fan remake de très bonne facture', '2018-02-17 16:25:02', '1970-01-01 00:00:00', 1, 0, NULL),
(6, 'JefGrailet', 'Un remake solide, quoique perfectible', '2018-02-17 16:25:02', '1970-01-01 00:00:00', 0, 0, NULL),
(7, 'Doppelganger', 'L\'épisode le plus sympa à rejouer', '2018-02-17 16:37:00', '1970-01-01 00:00:00', 0, 0, NULL),
(9, 'Doppelganger', 'Une alternative séduisante à Dark Souls', '2018-07-03 14:13:44', '2018-07-25 16:30:54', 1, 0, NULL),
(10, 'Doppelganger', 'Un excellent DLC avec des affrontements retors', '2018-07-18 15:12:33', '2018-07-18 15:17:42', 0, 0, NULL),
(11, 'JefGrailet', 'Un clin d\'oeil à Demon\'s Souls dans l\'alpha', '2018-07-23 19:04:41', '2018-07-25 22:21:57', 1, 0, NULL),
(12, 'JefGrailet', 'Et en fait, c\'est la suite de Dark Souls III', '2018-07-25 16:29:00', '2018-07-25 16:29:25', 0, 1, NULL),
(13, 'JefGrailet', 'Un chevalier qui a très faim', '2018-07-26 00:49:22', '1970-01-01 00:00:00', 2, 0, NULL),
(14, 'JefGrailet', 'Le clin d\'oeil musical du cartographe', '2018-07-26 00:59:07', '1970-01-01 00:00:00', 1, 0, NULL),
(15, 'JefGrailet', 'Jeux auxquels j\'ai joués en 2018', '2018-07-31 17:02:38', '2020-04-18 12:26:08', 2, 0, NULL),
(17, 'Nerdjaken', 'Les plus belles miches du JV', '2018-08-08 00:50:02', '1970-01-01 00:00:00', 0, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `map_tropes_reviews`
--

CREATE TABLE `map_tropes_reviews` (
  `tag` varchar(100) COLLATE utf8_unicode_520_ci NOT NULL,
  `id_commentable` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;

--
-- Déchargement des données de la table `map_tropes_reviews`
--

INSERT INTO `map_tropes_reviews` (`tag`, `id_commentable`) VALUES
('Exploration', 1),
('Nature et découverte', 1),
('Die and retry', 4),
('Exploration', 4),
('Nature et découverte', 4),
('En solitaire', 5),
('Exploration', 5),
('En solitaire', 6),
('Exploration', 6),
('Die and retry', 7),
('En solitaire', 7),
('Die and retry', 9),
('En solitaire', 9),
('Die and retry', 10),
('En solitaire', 10);

-- --------------------------------------------------------

--
-- Structure de la table `reviews`
--

CREATE TABLE `reviews` (
  `id_commentable` int(10) UNSIGNED NOT NULL,
  `game` varchar(100) COLLATE utf8_unicode_520_ci NOT NULL,
  `rating` tinyint(3) UNSIGNED NOT NULL,
  `comment` text COLLATE utf8_unicode_520_ci NOT NULL,
  `associated_tropes` varchar(510) COLLATE utf8_unicode_520_ci NOT NULL COMMENT 'Spares the effort of a SQL request for each review when listing a bunch of reviews.',
  `id_article` int(10) UNSIGNED DEFAULT NULL,
  `external_link` varchar(300) COLLATE utf8_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;

--
-- Déchargement des données de la table `reviews`
--

INSERT INTO `reviews` (`id_commentable`, `game`, `rating`, `comment`, `associated_tropes`, `id_article`, `external_link`) VALUES
(1, 'The Legend of Zelda: Breath of the Wild', 9, 'Pour son premier véritable monde ouvert au sens moderne en 3D, Nintendo ne déçoit pas. Bien au contraire! Plutôt que de simplement greffer de vastes étendues à la formule que l\'on connaissait déjà, Nintendo a adapté les codes de Zelda en 3D au monde ouvert en mettant l\'accent sur la liberté de mouvement et les interactions avec le décor. Le résultat final est une belle réussite et offre un monde vivant et riche, tant dans les interactions, les détails que dans le visuel, en plus d\'une aventure totalement non-linéaire. Cette mutation ambitieuse a toutefois un prix: le temps d\'un épisode, <em>Breath of the Wild</em> sacrifie en effet l\'identité graphique et la consistance des donjons qui faisaient jusqu\'ici la réputation des épisodes en 3D &quot;classiques&quot;. Peut-être pour mieux les remettre en valeur au prochain opus ? En fonction des sensibilités de chacun, on pourra également reprocher à <em>Breath of the Wild</em> ses affrontements un peu trop simples, ses quelques incohérences de level design ou encore le manque d\'intérêt à long terme de certains pans d\'Hyrule. En effet, difficile de garder la même soif d\'exploration, après avoir visité la majorité d\'Hyrule, quand on ne découvre plus que des Korogus ou des nouveaux emplacements pour des monstres déjà croisés ailleurs. Quoi qu\'il en soit, s\'il ne bouleverse pas le monde ouvert fondamentalement, la richesse et l\'élégance de la formule de <em>Breath of the Wild</em> en font un incontournable auquel les futurs jeux du genre seront inévitablement comparés.', 'Exploration,#6f90c6|Nature et découverte,#00af00', 1, NULL),
(4, 'The Legend of Zelda: Breath of the Wild', 10, 'Rien d\'autre à ajouter.', 'Die and retry,#6c6b6b|Exploration,#6f90c6|Nature et découverte,#00af00', NULL, NULL),
(5, 'Another Metroid 2 Remake', 8, 'Même si l\'on met de côté le fait qu\'il s\'agisse d\'un travail amateur, Another Metroid 2 Remake n\'en demeure pas moins une belle réussite. En reprenant fidèlement le gameplay des épisodes GBA et en actualisant le level design de son ancêtre sur GameBoy sans jamais le trahir, AM2R offre aussi bien un ravalement de façade salvateur pour un jeu qui en avait bien besoin qu\'un bel hommage à l\'ensemble de la série Metroid. Et c\'est sans oublier, bien sûr, sa finition impeccable. Quelques segments de l\'aventure moins réussis visuellement et quelques problèmes de fond trahissent toutefois ses origines de temps à autre. Quoi qu\'il arrive, nul doute qu\'AM2R pourra faire forte impression auprès d\'une partie des fans, et peut-être faire découvrir la série aux curieux à moindre frais.', 'En solitaire,#ac2f3e|Exploration,#6f90c6', 3, NULL),
(6, 'Metroid: Samus Returns', 8, 'Mission accomplie pour MercurySteam: avec son visuel soigné, ses révisions de gameplay comme de level design et son contenu très généreux, Samus Returns constitue un remake copieux de Metroid 2. Les fans les plus hardcore pourront toutefois lui reprocher certains choix au niveau des contrôles, en particulier sa mécanique de contre assez peu adaptée au style de la série (en dehors des combats contre les métroïdes) ainsi qu\'un manque flagrant d\'options pour la prise en main. On pourra aussi lui reprocher quelques décisions de level design qui allongent la durée de vie de manière un peu artificielle. Quoi qu\'il en soit, on n\'avait plus vu Samus Aran aussi en forme en deux dimensions depuis Zero Mission sur Game Boy Advance (2004). De quoi redonner de l\'espoir pour le futur de la série en 2D chez Nintendo... avec ou sans MercurySteam ?', 'En solitaire,#ac2f3e|Exploration,#6f90c6', 3, NULL),
(7, 'Dark Souls III', 8, 'Il y a sans doute une chiée de détails sur lesquels on peut chipoter, comme la pertinence de certains niveaux, la linéarité du monde et pas mal de clins d\'oeil un peu trop appuyés au premier épisode \'remarque, on peut comprendre que From veuille oublier le II...), toujours est-il que c\'est l\'épisode le mieux fini et dont la prise en main est la plus agréable! Une valeur sûre quoi qu\'il arrive.', 'Die and retry,#6c6b6b|En solitaire,#ac2f3e', NULL, NULL),
(9, 'Bloodborne', 8, 'Je ne fais que tester, encore et encore... mais ça a l\'air de marcher jusqu\'ici !', 'Die and retry,#6c6b6b|En solitaire,#ac2f3e', NULL, 'http://php.net/manual/en/function.strpos.php|La fonction strpos() de PHP'),
(10, 'Bloodborne: The Old Hunters', 9, 'Autant je n\'étais pas fan du derniers tiers de Bloodborne, la faute notamment à des <em>bosses</em> qui manquent de folie (à quelques exceptions près), autant ce contenu additionnel m\'a scotché de bout en bout. Certes, le <em>level design</em> est un chouia linéaire, à la manière du DLC <em>Artorias of the Abyss</em> du premier Dark Souls, mais comme ce dernier, <em>The Old Hunters</em> propose des ennemis redoutables, incluant des <em>bosses</em> bien costauds, mais aussi de nouvelles armes rigolotes et une excellente OST, qui brille en particulier pour son utilisation du violoncelle. C\'est un poil court (quelques heures tout au plus), mais raisonnable.', 'Die and retry,#6c6b6b|En solitaire,#ac2f3e', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `tags`
--

CREATE TABLE `tags` (
  `tag` varchar(100) COLLATE utf8_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;

--
-- Déchargement des données de la table `tags`
--

INSERT INTO `tags` (`tag`) VALUES
('AM2R'),
('Another Metroid 2 Remake'),
('AoA'),
('Aventure'),
('BB'),
('Bloodborne'),
('Bloodborne: The Old Hunters'),
('Collectathon'),
('Dark Souls'),
('Dark Souls 2'),
('Dark Souls II'),
('Dark Souls II: Crown of the Ivory King'),
('Dark Souls II: Crown of the Old Iron King'),
('Dark Souls II: Crown of the Sunken King'),
('Dark Souls II: Scholar of the First Sin'),
('Dark Souls III'),
('Dark Souls III: Ashes of Ariandel'),
('Dark Souls III: The Ringed City'),
('DaS'),
('DaS II'),
('DaS III'),
('DaS2'),
('DaS3'),
('Death Stranding'),
('Demon\'s Souls'),
('DeS'),
('Développement'),
('Die and retry'),
('DkS'),
('DkS 2'),
('DkS II'),
('DkS2'),
('DkSII'),
('DS'),
('DS II'),
('DS III'),
('DS2'),
('DS3'),
('DSII'),
('En solitaire'),
('Exploration'),
('friendship'),
('GR2'),
('Gravity Daze'),
('Gravity Rush 2'),
('Histoire avec un grand H'),
('HK'),
('Hollow Knight'),
('Jeu cinématique'),
('jeu video'),
('LM3'),
('LO'),
('Lol'),
('Lololo'),
('Lost Crowns'),
('Luigi\'s Mansion 3'),
('meeting'),
('Metal Gear Rising: Revengeance'),
('Metroid 2'),
('Metroid II'),
('Metroid SR'),
('Metroid: Samus Returns'),
('MG Rising'),
('MGR'),
('MH'),
('MH3 Ultimate'),
('MH3U'),
('MH4U'),
('MHGU'),
('MHW'),
('MM3D'),
('Monde ouvert'),
('MonHun'),
('MonHun World'),
('Monster Hunter 3 Ultimate'),
('Monster Hunter 4 Ultimate'),
('Monster Hunter Generations Ultimate'),
('Monster Hunter Tri Ultimate'),
('Monster Hunter World'),
('MSR'),
('Mythes et folklore'),
('Nature et découverte'),
('Nintendo Switch'),
('OaP'),
('Project AG'),
('Règles'),
('SDT'),
('Sekiro: Shadows Die Twice'),
('Shadow of the Colossus (Remake)'),
('SOTC'),
('SOTFS'),
('TCB'),
('Te'),
('Test'),
('The Last of Us'),
('The Legend of Zelda: Breath of the Wild'),
('The Legend of Zelda: Breath of the Wild - L\'Ode aux Prodiges'),
('The Legend of Zelda: Link\'s Awakening (Remake)'),
('The Legend of Zelda: Majora\'s Mask 3D'),
('The Legend of Zelda: Ocarina of Time 3D'),
('The Legend of Zelda: Skyward Sword'),
('The Legend of Zelda: The Wind Waker'),
('The Legend of Zelda: The Wind Waker HD'),
('The Legend of Zelda: Twilight Princess'),
('The Legend of Zelda: Twilight Princess HD'),
('The Outer Worlds'),
('The Witness'),
('TLOU'),
('TLoZ LA'),
('TLoZ MM 3D'),
('TLoZ OoT 3D'),
('TLoZ TP'),
('TLoZ TWW HD'),
('TOH'),
('TOW'),
('TRC'),
('TW'),
('Zelda BoTW'),
('zelda ss'),
('zelda tp'),
('zelda tww');

-- --------------------------------------------------------

--
-- Structure de la table `tropes`
--

CREATE TABLE `tropes` (
  `tag` varchar(100) COLLATE utf8_unicode_520_ci NOT NULL,
  `color` varchar(10) COLLATE utf8_unicode_520_ci NOT NULL DEFAULT '#BFBFBF',
  `description` varchar(250) COLLATE utf8_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;

--
-- Déchargement des données de la table `tropes`
--

INSERT INTO `tropes` (`tag`, `color`, `description`) VALUES
('Collectathon', '#63c166', 'Chaque recoin du monde regorge d\'objets uniques à dénicher. En explorant, vous augmenterez vos réserves d\'objets et pourrez débloquer de nouveaux pouvoirs, restaurer votre énergie et ouvrir l\'accès à de nouveaux mondes !'),
('Die and retry', '#6c6b6b', 'Dans ce jeu, les erreurs du joueur sont très vite sanctionnées et l\'échec fait partie intégrante de l\'apprentissage du joueur, d\'où le terme &quot;die and retry&quot; (&quot;meurs et réessaye&quot;). Souvent associé à des jeux old school.'),
('En solitaire', '#ac2f3e', 'Ce jeu met l\'accent sur la solitude du joueur et évite autant que possible toute cinématique, dialogue ou indice. Le joueur y est souvent livré à lui-même, tant sur le plan ludique que scénaristique.'),
('Exploration', '#6f90c6', 'Ce jeu comporte des zones ouvertes que le joueur pourra visiter pour glaner diverses récompenses, progresser dans sa quête ou simplement flâner. Propice à une progression non-linéaire.'),
('Histoire avec un grand H', '#8767ff', 'L\'univers du jeu et/ou son scénario s\'inspirent d\'évènements historiques. Selon les intentions des développeurs, la réalité historique peut être altérée pour y insérer un scénario inédit ou expliquer des éléments du gameplay.'),
('Jeu cinématique', '#ba1bff', 'Ce jeu est porté sur le développement de son scénario, via un grand nombre de cinématiques et dialogues prenant parfois le pas sur les phases de gameplay. Ce type de jeu emprunte souvent des codes au 7e art.'),
('Mythes et folklore', '#a578f5', 'L\'univers de ce jeu se base en partie ou en totalité sur une mythologie existante ou sur le folklore d\'un pays. Parfois, des quêtes entières se baseront sur des contes et légendes populaires tirés de ceux-ci.'),
('Nature et découverte', '#00af00', 'L\'environnement graphique de ce jeu met l\'accent sur la richesse et/ou la variété de sa faune et de sa flore. Il est souvent possible d\'interagir avec celles-ci pour progresser dans le jeu ou obtenir des avantages.');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `commentables`
--
ALTER TABLE `commentables`
  ADD PRIMARY KEY (`id_commentable`),
  ADD KEY `commentables_ibkf_2` (`pseudo`),
  ADD KEY `commentables_ibkf_1` (`id_topic`);

--
-- Index pour la table `map_tropes_reviews`
--
ALTER TABLE `map_tropes_reviews`
  ADD PRIMARY KEY (`tag`,`id_commentable`),
  ADD UNIQUE KEY `tag` (`tag`,`id_commentable`),
  ADD KEY `id_commentable` (`id_commentable`);

--
-- Index pour la table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id_commentable`),
  ADD KEY `reviews_ibfk_2` (`game`),
  ADD KEY `reviews_ibfk_3` (`id_article`);

--
-- Index pour la table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tag`);

--
-- Index pour la table `tropes`
--
ALTER TABLE `tropes`
  ADD PRIMARY KEY (`tag`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `commentables`
--
ALTER TABLE `commentables`
  MODIFY `id_commentable` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commentables`
--
ALTER TABLE `commentables`
  ADD CONSTRAINT `commentables_ibkf_1` FOREIGN KEY (`id_topic`) REFERENCES `topics` (`id_topic`) ON DELETE SET NULL,
  ADD CONSTRAINT `commentables_ibkf_2` FOREIGN KEY (`pseudo`) REFERENCES `users` (`pseudo`);

--
-- Contraintes pour la table `map_tropes_reviews`
--
ALTER TABLE `map_tropes_reviews`
  ADD CONSTRAINT `map_tropes_reviews_ibfk_1` FOREIGN KEY (`tag`) REFERENCES `tropes` (`tag`) ON DELETE CASCADE,
  ADD CONSTRAINT `map_tropes_reviews_ibfk_2` FOREIGN KEY (`id_commentable`) REFERENCES `reviews` (`id_commentable`) ON DELETE CASCADE;

--
-- Contraintes pour la table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`id_commentable`) REFERENCES `commentables` (`id_commentable`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`game`) REFERENCES `games` (`tag`),
  ADD CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`id_article`) REFERENCES `articles` (`id_article`);

--
-- Contraintes pour la table `tropes`
--
ALTER TABLE `tropes`
  ADD CONSTRAINT `tropes_ibfk_1` FOREIGN KEY (`tag`) REFERENCES `tags` (`tag`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
