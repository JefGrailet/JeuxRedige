-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Hôte : mysql168.webhosting.be:3306
-- Généré le : lun. 04 mai 2020 à 20:13
-- Version du serveur :  5.7.29-32-log
-- Version de PHP : 7.1.25-1+0~20181207224605.11+jessie~1.gbpf65b84

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ID202894_pagmain`
--

-- --------------------------------------------------------

--
-- Structure de la table `_map_favourites`
--

CREATE TABLE `_map_favourites` (
  `pseudo` varchar(20) COLLATE utf8_unicode_520_ci NOT NULL,
  `id_topic` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_520_ci;

-- --------------------------------------------------------

--
-- Structure de la table `_map_tropes_games`
--

CREATE TABLE `_map_tropes_games` (
  `trope` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_520_ci NOT NULL,
  `game` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_520_ci COMMENT='This mapping might not be crucial for now. It seems some good SQL requests might be enough to implement (dynamic) trope selection for a game.';

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `_map_favourites`
--
ALTER TABLE `_map_favourites`
  ADD PRIMARY KEY (`pseudo`,`id_topic`),
  ADD UNIQUE KEY `pseudo` (`pseudo`,`id_topic`),
  ADD KEY `id_topic` (`id_topic`);

--
-- Index pour la table `_map_tropes_games`
--
ALTER TABLE `_map_tropes_games`
  ADD PRIMARY KEY (`trope`,`game`),
  ADD UNIQUE KEY `tag` (`trope`,`game`),
  ADD KEY `map_tropes_games_ibfk_2` (`game`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `_map_favourites`
--
ALTER TABLE `_map_favourites`
  ADD CONSTRAINT `_map_favourites_ibfk_1` FOREIGN KEY (`pseudo`) REFERENCES `users` (`pseudo`),
  ADD CONSTRAINT `_map_favourites_ibfk_2` FOREIGN KEY (`id_topic`) REFERENCES `topics` (`id_topic`) ON DELETE CASCADE;

--
-- Contraintes pour la table `_map_tropes_games`
--
ALTER TABLE `_map_tropes_games`
  ADD CONSTRAINT `_map_tropes_games_ibfk_1` FOREIGN KEY (`trope`) REFERENCES `tropes` (`tag`) ON DELETE CASCADE,
  ADD CONSTRAINT `_map_tropes_games_ibfk_2` FOREIGN KEY (`game`) REFERENCES `games` (`tag`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
