# Archivage du 04/05/2020

*Document rédigé par Jean-François Grailet (JefGrailet)*

## Ce qui a été archivé

Les évaluations de jeux (c.-à-d. pas les articles de type "critique", mais les évaluations courtes 
pour les jeux) et les codes vidéoludiques ont été retirés du site. Tous les fichiers exclusifs à 
ces fonctionnalités sont contenus dans cette archive ZIP. Les fichiers qui sont toujours présents 
dans le code du site mais qui ont dû être modifiés sont également présents sous forme de copie 
"pré-archivage" (voir plus bas).

Le concept de ces évaluations et codes vidéoludiques (ou "tropes") était le suivant: en évaluant 
un jeu, un utilisateur pouvait l'associer à un ou plusieurs code vidéoludique, ou "trope", c.-à-d. 
un archétype de jeu (comme exemple le "collectathon" qui n'est pas tout à fait un genre de jeu 
mais un type d'activité dans un jeu). Les "tropes" les plus cités par les utilisateurs sur une 
fiche de jeu auraient ensuite été mis en avant sur la page du jeu, afin de mieux décrire sa nature 
(en bien ou en mal) au visiteur. Un moteur de recherche basé sur ces tropes avait été également 
créé pour l'occasion.

## Raisons de l'archivage

La motivation pour cet archivage est la suivante: ces fonctionnalités étaient trop particulières, 
trop "sur-mesure" (je n'ai d'ailleurs pas pris le temps de les expliquer à plusieurs visiteurs du 
site) et il aurait fallu une solide communauté derrière pour que ça donne quelque chose. En 
l'état, bien que j'étais satisfait de l'implémentation, je préfère enlever tout ceci et le mettre 
de côté pour me concentrer sur des choses plus simples et pour lesquelles il me faut moins de 
travail, que ce soit pour l'implémentation ou la création du contenu. Tout ce qui est 
"Commentable" est donc conservé (et pourra être étendu à l'avenir) mais les évaluations avec la 
possibilité de mapper des "tropes" aux jeux sont mises de côté.

Ceci étant dit, à l'avenir, il peut être intéressant de créer un système de tags commentés pour 
les jeux, un peu à la manière de ce qu'on voit sur IMDB. Avec un bon design, il y a sans doute 
moyen de faire quelque chose de simple et utile. En attendant, je préfère faire un ravalement de 
façade au site et mieux mettre en évidence la partie anecdotes et une éventuelle partie astuces.

## Base de données

`ID202894_pagmain.sql` donne les tables exclusives aux évaluations (`reviews`) et aux codes 
vidéoludiques (`tropes`) ainsi que les tables liées mais toujours présentes dans la BDD actuelle 
de PAG (dont `commentables`).

`ID202894_pagmain_misc.sql` donne deux vieilles tables également retirées de la BDD en passant: 
une vieille table pour garder en mémoire les topics favoris d'un utilisateur (`_map_favourites`) 
et un prototype de mapping entre jeux et codes vidéoludiques (`_map_tropes_games`). Aucune des 
deux tables n'était utilisée en pratique, chacune étant d'ailleurs préfixée par `_`; je les ai 
retirées seulement pour que la BDD soit plus propre.

## Fichiers toujours présents mais modifiés

Ces fichiers n'ont pas été retirés du site après archivage des fonctionnalités citées 
ci-contre car toujours utiles au fonctionnement site. Une copie d'avant archivage a été conservée 
dans cette archive afin de garder une trace de comment ces fonctionnalités étaient intégrées au 
reste du site (s'il fallait, par exemple, les restituer plus tard).

`src/javascript/formatting.js`

`src/libraries/Buffer.lib.php`
`src/libraries/Header.lib.php`
`src/libraries/Keywords.lib.php`

`src/model/Commentable.class.php`
`src/model/Game.class.php`
`src/model/Tag.class.php`

`src/style/default.css`
`src/style/game_content.css`
`src/style/media.css`
`src/style/pool.css`

`src/view/content/Games.ctpl`
`src/view/content/Games.fail.ctpl`

`src/view/intermediate/Commentable.ir.php`
`src/view/intermediate/TopicHeader.ir.php`

`src/view/Header.inc.php`

`src/.htaccess`
`src/DeleteContent.php`
`src/Game.php`
`src/NewComments.php`
